package Book03_ObjectOrientatedProgramming.Chapter05.UsingInterfaces.IntefaceAsAType;

public interface Playable {
    void play();
}
