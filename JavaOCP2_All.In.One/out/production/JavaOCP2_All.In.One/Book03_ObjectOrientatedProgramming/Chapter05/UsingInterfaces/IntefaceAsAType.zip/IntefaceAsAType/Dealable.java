package Book03_ObjectOrientatedProgramming.Chapter05.UsingInterfaces.IntefaceAsAType;

public interface Dealable  {
    void deal(int cards);

}
