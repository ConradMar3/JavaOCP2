package Book03_ObjectOrientatedProgramming.Chapter05.UsingInterfaces.IntefaceAsAType;

import java.util.Scanner;

public class Game {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Poker p = new Poker();
        Game game = new Game();
        game.startGame((Dealable) p, "Poker");
    }

    private void startGame(Dealable deck, String game) {
        if (game.equals("Poker"))
            deck.deal(5);
        else if (game.equals("Hearts"))
            deck.deal(13);
        else if (game.equals("Gin"))
            deck.deal(10);
    }
}
