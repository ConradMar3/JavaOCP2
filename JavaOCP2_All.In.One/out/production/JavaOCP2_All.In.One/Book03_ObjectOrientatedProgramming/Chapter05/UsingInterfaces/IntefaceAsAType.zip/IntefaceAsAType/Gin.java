package Book03_ObjectOrientatedProgramming.Chapter05.UsingInterfaces.IntefaceAsAType;

public class Gin implements Playable, CardGame {
    @Override
    public void play() {
        System.out.println("Playing Gin.");
    }
    // must implement methods of the Playable
    // and CardGame interfaces
}
