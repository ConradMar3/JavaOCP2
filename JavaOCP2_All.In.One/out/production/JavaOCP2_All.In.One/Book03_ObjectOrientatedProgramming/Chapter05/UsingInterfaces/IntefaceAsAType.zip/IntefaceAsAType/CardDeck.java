package Book03_ObjectOrientatedProgramming.Chapter05.UsingInterfaces.IntefaceAsAType;

public class CardDeck implements Dealable{



    @Override
    public void deal(int cards) {

    }
}
