package Book03_ObjectOrientatedProgramming.Chapter05.UsingInterfaces.IntefaceAsAType;

public class Hearts implements Playable, CardGame {
    @Override
    public void play() {
        System.out.println("Playing Hearts.");
    }
    // must implement methods of the Playable
    // and CardGame interfaces
}
